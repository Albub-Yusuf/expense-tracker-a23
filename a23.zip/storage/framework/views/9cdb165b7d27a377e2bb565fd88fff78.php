<div class="container">
    <div class="row mx-auto">
        <div class="col-md-12 col-sm-12 col-lg-12 d-flex flex-wrap-reverse align-items-center justify-content-center">
        
        <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

       
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-2 text-gray-900">
                     <h2 class="my-2 text-center text-danger" >Total Summary</h2>

                    <h2 class="my-2 text-right text-success">Total Income = <?php echo e($totalIncome); ?> BDT</h2>
                    <h2 class="my-2 text-right text-danger">Total Expense = <?php echo e($totalExpense); ?> BDT</h2>
                    <hr style="width: 50%; float:right;"><br>
                    <h2 class="my-2 text-right text-primary">Net Income= <?php echo e($balanced); ?> BDT</h2>


                </div>
            </div>

        </div>
       
        </div>
        </div>


        <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

       
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-2 text-gray-900">
                     <h2 class="my-2 text-center text-danger">Current Month Summary</h2>

                    <h2 class="my-2 text-right text-success">Total Income = <?php echo e($currentMonthIncome); ?> BDT</h2>
                    <h2 class="my-2 text-right text-danger">Total Expense = <?php echo e($currentMonthExpense); ?> BDT</h2>
                    <hr style="width: 50%; float:right;"><br>
                    <h2 class="my-2 text-right text-primary">Balance= <?php echo e($currentMonthBalance); ?> BDT</h2>


                </div>
            </div>

        </div>
       
        </div>
        </div>

       
        </div>
    </div>
    </div><?php /**PATH D:\23a\resources\views/myComponents/summary.blade.php ENDPATH**/ ?>