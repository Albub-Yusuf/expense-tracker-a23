<div class="row">
<div class="col-md-10">
  <h1 class="text-center mt-4" style="font-size: 18px; font-weight:600;">Expense Records</h1>
<div class="d-flex items-center justify-content-between">
<h2 class="my-4 text-right text-primary" style="font-size: 18px; font-weight:600;">Total Expense = <?php echo e($recordsTotal); ?> BDT</h2>
</div>
<table class="table" id="expense_list">
  <thead>
    <tr>
      <th>Serial</th>
      <th>Expense</th>
      <th>Amount</th>
      <th>Category</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
   <?php $__currentLoopData = $recordsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   <tr>
      <td><?php echo e($serial++); ?></td>
      <td><?php echo e($expense->details); ?></td>
      <td><?php echo e($expense->amount); ?></td>
      <td><?php echo e($expense->category->category); ?></td>
      <td><?php echo e($expense->date); ?></td>
    </tr>
    
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  
</table>

</div>
</div>

<script>
 $(function() {
   $('#expense_list').DataTable();
 });
</script><?php /**PATH D:\23a\resources\views/records/expenseList.blade.php ENDPATH**/ ?>