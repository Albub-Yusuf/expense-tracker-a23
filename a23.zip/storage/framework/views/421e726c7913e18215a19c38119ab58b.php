<div class="row">
<div class="col-md-10">
  <h1 class="text-center mt-4" style="font-size: 18px; font-weight:600;">Income Records</h1>
<div class="d-flex items-center justify-content-between">
<h2 class="my-4 text-right text-primary" style="font-size: 18px; font-weight:600;">Total Income = <?php echo e($recordsTotal); ?> BDT</h2>
</div>
<table class="table" id="income_list">
  <thead>
    <tr>
      <th>Serial</th>
      <th>Income</th>
      <th>Amount</th>
      <th>Date</th>
    </tr>
  </thead>
  <tbody>
   <?php $__currentLoopData = $recordsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   <tr>
      <td><?php echo e($serial++); ?></td>
      <td><?php echo e($income->details); ?></td>
      <td><?php echo e($income->amount); ?></td>
      <td><?php echo e($income->date); ?></td>
    </tr>
    
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  
</table>

</div>
</div>

<script>
 $(function() {
   $('#income_list').DataTable();
 });
</script><?php /**PATH D:\23a\resources\views/records/incomeList.blade.php ENDPATH**/ ?>