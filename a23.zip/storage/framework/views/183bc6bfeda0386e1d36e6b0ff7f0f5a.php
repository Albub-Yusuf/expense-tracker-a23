<div class="container mt-5">
    <h1 class="text-center my-4" style="font-size: 18px; font-weight:600;">Income & Expense Balance Sheet</h1>
    <table class="table table-bordered">
        <tbody style="font-size: 18px; font-weight:600;">
            <tr>
                <th>Category</th>
                <th>Amount</th>
            </tr>
            <tr class="text-success" style="font-size: 18px; font-weight:600;">
                <td>Income</td>
                <td><?php echo e($recordsTotalIncome); ?> BDT</td>
            </tr>
            <tr class="text-danger">
                <td>Expense</td>
                <td><?php echo e($recordsTotalExpense); ?> BDT</td>
            </tr>
            <tr>
                <td>Balance</td>
                <td><?php echo e($recordsTotalIncome - $recordsTotalExpense); ?> BDT</td>
            </tr>
        </tbody>
    </table>
</div><?php /**PATH D:\23a\resources\views/records/balanceList.blade.php ENDPATH**/ ?>